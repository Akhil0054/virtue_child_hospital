

  // start testimonial section 
  var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1, 
    spaceBetween: 30,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    autoplay: {
        delay: 3000, 
        disableOnInteraction: false,
    },
    breakpoints: {
        640: {
            slidesPerView: 1, 
            spaceBetween: 10,
        },
        768: {
            slidesPerView: 2, 
            spaceBetween: 20,
        },
        1024: {
            slidesPerView: 3, 
            spaceBetween: 30,
        },
    },
  });
  // end testimonial section 

AOS.init();

window.addEventListener('scroll', function() {
  const navbar = document.querySelector('.navbar');
  if (window.scrollY > 0) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
});












  // start top scroll button 
 
window.onscroll = function() {
  const button = document.querySelector('.scroll-to-top');
  if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
      button.classList.add('visible');
  } else {
      button.classList.remove('visible');
  }
};

document.querySelector('.scroll-to-top').onclick = function() {
  window.scrollTo({ top: 0, behavior: 'smooth' });
};


  // end top scroll button 









